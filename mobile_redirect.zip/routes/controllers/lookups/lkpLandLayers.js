const obtainLayers = require("../../common/obtainLayers")
const reply = require("../../common/reply")
const { manageTokens, enumTokenNames } = require("../../common/token/manageTokens")

const apiErrorCode = "LookupTypes"

module.exports = async (req, res, next) => {
    try {
        let tokenData = await manageTokens(enumTokenNames.lands)
        if (!tokenData || tokenData == undefined || tokenData == null || !Object.values(tokenData).length) {
            throw reply.error({
                errorCode: "LayersAreDown",
                message: "معطل للصيانة - Server Maintenance",
                internalData: "Token service is down"
            })
        }
        let layerSection = await obtainLayers(tokenData.token, process.env.URL_LANDS, /* { folderName: "DLS" } */)
        return res.send(reply.done(layerSection))
    } catch (err) {
        console.log('failed to obtain layers look')
        console.log(err)
        try {
            if (!reply.validateError(err)) {
                if (err.includes("Could not access any server machines")) {
                    return next(reply.passError(apiErrorCode,
                        reply.error({
                            errorCode: "LayersAreDown",
                            message: "معطل للصيانة - Server Maintenance",
                            internalData: err
                        })
                    ))
                }
            } else {
                if (err.errorCode == "FailedToObtainToken") {
                    return next(reply.passError(apiErrorCode,
                        reply.error({
                            errorCode: "LayersAreDown",
                            message: "معطل للصيانة - Server Maintenance.",
                            internalData: err
                        })
                    ))
                }
            }
        } catch (err) {
            console.log(err)
            console.log('undefined error')
        }

        next(reply.passError(apiErrorCode, err))
    }
}